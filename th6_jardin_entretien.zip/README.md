# setTimeout
Régler le pb de récursivité en ajoutant une Immediatly Exec Fct @see IEF.
